﻿This is project for techgig competion.

Information on this project.

1. This is maven project.
2. it is an user interaction project.
3. The test cases are my own developed similar to the ones required for the competion but with some modifications.
4. Jars required are already present in the lib folder.
5. Code should be used only for competion purpose.

Requesites.

1. Windows OS(vista or higher) or iOS.
2. Hardisk space: 30Mb Ram: 2GB or more(for smooth experience)
3. Eclipse IDE.
4. good internet speed(for downloading the dependencies).
5. jdk 1.6.1 or higher.


Directions.

1. in eclipse import the project as a maven project.(refer to screenshots in doc folder)
2. expand the project.
3. in Windows--> preferences-->Java--> installed jres--> add-->(add the required jars from jdk folder in Java folder in C:drive)
4. run the project
5 set the goal as 'clean package install' 
6. Apply and run.
(screenshots of the process present in screen shots.docx file in doc folder.



