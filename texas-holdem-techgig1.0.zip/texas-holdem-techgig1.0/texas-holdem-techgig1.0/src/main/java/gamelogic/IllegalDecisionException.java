package gamelogic;

/**
 * 
 */
public class IllegalDecisionException extends Throwable {
    public IllegalDecisionException() {}
    public IllegalDecisionException(String message) {
        super(message);
    }
}
